export const DEFAULT_ARROW_SIZE = 14;
